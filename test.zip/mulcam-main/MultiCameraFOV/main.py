import os

import numpy
from PIL import Image
from patchify import patchify, unpatchify
from torchvision.transforms.functional import get_image_size, rotate
from torchvision.transforms.functional import pil_to_tensor
from sklearn.feature_extraction import image
from torchvision.utils import save_image
from skimage import transform

from analyzeFundamentalMatrix import analyze_fundamental_matrix, compare_fundamental_matrix
from attack.CAttack import CAttack
from attack.CGlobalAttack import CGlobalAttack
from attack.CPatchAttack import CPatchAttack
from defense.CDefense import CDefense
from my_utils import Constants
from my_utils.show_result import show_result, plot_roc


if __name__ == "__main__":
    # compare_fundamental_matrix(r"/home/angli19/data/fundamental_matrix/KITTI-360/fundamental_matrix_list_C1_C2.npy",
    #                            r"/home/angli19/data/fundamental_matrix/KITTI-360/fundamental_matrix_list_C1_C2_realtime_1_1_45.npy")
    # compare_fundamental_matrix(r"/home/angli19/data/fundamental_matrix/KITTI-360/fundamental_matrix_list_C1_C2.npy",
    #                            r"/home/angli19/data/fundamental_matrix/KITTI-360/fundamental_matrix_list_C1_C2.npy")

    # analyze_fundamental_matrix(r"/home/angli19/data/fundamental_matrix/KITTI-360")
    ## get home directory of current user
    home_directory = os.path.expanduser('~')
    ## data directory
    data_directory = r"data/image_data"
    data_path_name = os.path.join(home_directory, data_directory)

    ## input data folder name
    input_data_folder_name = r"raw_images"
    ## input dataset name
    # input_dataset_name = "wildtrack"
    input_dataset_name = "KITTI-360"
    ## output data folder name
    output_data_folder_name = r"modified_images"
    ## output dataset name
    # output_dataset_name = r"modified_wildtrack"
    output_dataset_name = r"modified_kitti_360"

    ## config directory
    config_dir_name = r"multi_camera_config"
    ## label result
    label_dir_name = r"results/label"

    input_dir_name = os.path.join(data_path_name, input_data_folder_name, input_dataset_name)
    output_dir_name = os.path.join(data_path_name, output_data_folder_name, output_dataset_name)

    label_file_dir = os.path.join(home_directory, "data", label_dir_name)

    label_file_list = os.listdir(label_file_dir)

    pos_file_name = os.path.join(label_file_dir, label_file_list[0])
    for i in range(3, len(label_file_list)):
        out_file_name = os.path.join(r"/home/angli19/data/fig",
                                     label_file_list[i][label_file_list[i].rfind(r"_")
                                                        + 1:label_file_list[i].rfind(r".")])

        # plot_roc(pos_file_name, os.path.join(label_file_dir, label_file_list[i]),
        #          out_file_name=out_file_name + "_ROC_EER.eps", is_authentic=1)


    # for cur_label_file_name in label_file_list:
    #     if os.path.join(r"/home/angli19/data/fig", r"KITTI-360") == out_file_name:
    #         cur_is_authentic = 1
    #     else:
    #         cur_is_authentic = 0
    #     plot_roc(os.path.join(label_file_dir, cur_label_file_name), out_file_name=out_file_name + "_ROC_EER.eps", is_authentic=cur_is_authentic)

    new_attack = CGlobalAttack(input_dir_name, output_dir_name, manipulate_tech_list=[Constants.IMG_ROTATION],
                               rotation_angle=45)
    # new_attack = CGlobalAttack(input_dir_name, output_dir_name, manipulate_tech_list=
    #                           [Constants.IMG_HORIZONTAL_FLIPPING])
    # new_attack = CGlobalAttack(input_dir_name, output_dir_name,
    #                            manipulate_tech_list=[Constants.IMG_AFFINE_TRANSFORMATION])
    # new_attack = CGlobalAttack(input_dir_name, output_dir_name,
    #                            manipulate_tech_list=[Constants.IMG_CROPPING_RESIZE])
    # new_attack = CGlobalAttack(input_dir_name, output_dir_name,
    #                            manipulate_tech_list=[Constants.IMG_GAUSSIAN_BLURRING])
    # new_attack = CGlobalAttack(input_dir_name, output_dir_name,
    #                            manipulate_tech_list=[Constants.IMG_COLOR_JITTER])
    # new_attack = CGlobalAttack(input_dir_name, output_dir_name,
    #                            manipulate_tech_list=[Constants.IMG_GRAYSCALE])

    # new_attack = CPatchAttack(input_dir_name, output_dir_name)

    # attack_compromised_cam_list = ['C1']
    # new_attack.attack_pipeline(compromised_cam_num=len(attack_compromised_cam_list), compromised_cam_list=attack_compromised_cam_list)

    config_file_name = r"KITTI_360.yaml"
    authentic_dir_name = input_dir_name
    new_data_dir_name = output_dir_name

    config_dir_file_name = os.path.join(data_path_name, input_data_folder_name, config_dir_name, config_file_name)
    mydefense = CDefense(authentic_dir_name, new_data_dir_name, config_dir_file_name, input_dataset_name)
    # mydefense.cal_authentic_fundamental_matrix()


    ## orignal dataset
    new_data_dir = input_dir_name
    # new_data_dir = os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/rotation/45")
    # new_data_dir = os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/flipping")
    # new_data_dir = os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/affine_trans")
    # new_data_dir = os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/cropping_resize")
    # new_data_dir = os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/gaussian_blur")
    # new_data_dir = os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/color_jitter")
    # new_data_dir = os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/grayscale")

    # mydefense.cal_authentic_fundamental_matrix()
    new_data_dir_list = [os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/flipping"),
                         os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/affine_trans"),
                         os.path.join(data_path_name, output_data_folder_name, output_dataset_name, "global/cropping_resize")]
    for new_data_dir in new_data_dir_list:
        if new_data_dir == r'/home/angli19/data/image_data/raw_images/KITTI-360':
            cur_is_authentic = 1
        else:
            cur_is_authentic = 0
        # pass
        mydefense.cal_realtime_fundamental_matrix(new_data_dir, str(Constants.GLOBAL_ATTACK) + "_"
                                              + str(Constants.IMG_ROTATION) + "_" + str(45), is_authentic=cur_is_authentic,
                                                  label_file_name_part=new_data_dir[new_data_dir.rfind("/")+1:])

    # mydefense.cal_realtime_fundamental_matrix(authentic_dir_name, str(Constants.GLOBAL_ATTACK) + "_"
    #                                           + str(Constants.IMG_ROTATION) + "_" + str(45))
    # mydefense.cal_realtime_fundamental_matrix(authentic_dir_name, str(Constants.GLOBAL_ATTACK) + "_"
    #                                           + str(Constants.IMG_ROTATION) + "_" + str(45))
    pass