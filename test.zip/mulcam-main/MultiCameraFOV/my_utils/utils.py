"""
THis file stores some common util functions
"""
import random

import numpy as np
import torch
import torch.nn.functional as F
from PIL.ImageDraw import ImageDraw
from torchvision.transforms import ToTensor, ToPILImage
from PIL import Image
import torchvision.transforms.functional as TF
import cv2

from my_utils.geometricTransformation import calculateHomography, geometricDistance, displayMatches, findMatchFeatures, \
    pos1, findMatchFeatures_ORB, findMatchFeatures_SURF

# from geometricTransformation import calculateHomography, geometricDistance, findMatchFeatures, displayMatches





def ransacHomography(corrList, threshold):
    maxInliers = []
    finalHomography = None

    for i in range(1000):
        # find 4 random points to calculate a homography
        corr1 = corrList[random.randrange(0, len(corrList))]
        corr2 = corrList[random.randrange(0, len(corrList))]
        randomFour = np.vstack((corr1, corr2))
        corr3 = corrList[random.randrange(0, len(corrList))]
        randomFour = np.vstack((randomFour, corr3))
        corr4 = corrList[random.randrange(0, len(corrList))]
        randomFour = np.vstack((randomFour, corr4))

        # finds the homography function for those points
        h = calculateHomography(randomFour)

        # NEED TO SEND P1 POINTS & H TO applyHomography, then calc Ej & inliers
        # runs over each pair of matched points [x1,y1,x'1,y'1]
        inliers = geometricDistance(corrList, h, 10)  # why inlierTol is 5 ??

        if len(inliers) > len(maxInliers):
            maxInliers = inliers
            finalHomography = h

        if len(maxInliers) > (len(corrList) * threshold):
            break
    return finalHomography, maxInliers

def extract_color_boundary(img, raw_img, color=[0, 0, 0]):
    # Load the image
    # img = cv2.imread(image)

    # Convert the image to the RGB color space
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Define the lower and upper color bounds in RGB format
    lower_color = np.array(color)
    upper_color = np.array(color)

    # Create a mask based on the specified color range
    mask = cv2.inRange(img_rgb, lower_color, upper_color)

    # Find contours in the mask
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Draw the contours on the original image
    cv2.drawContours(raw_img, contours, -1, (0, 255, 0), 2)

    # Display the original image with color boundary
    cv2.imshow("Color Boundary", raw_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    pass


def find_overlapping_area_1(img_1, img_2, store_img_path=""):
    img1 = cv2.imread(img_1)
    img2 = cv2.imread(img_2)

    # Convert the images to grayscale
    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

    # Initialize the feature detector
    detector = cv2.ORB_create()

    # Find keypoints and descriptors in the images
    keypoints1, descriptors1 = detector.detectAndCompute(gray1, None)
    keypoints2, descriptors2 = detector.detectAndCompute(gray2, None)

    # Initialize the feature matcher
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

    # Match keypoints in the images
    matches = matcher.match(descriptors1, descriptors2)

    # Sort the matches by distance
    matches = sorted(matches, key=lambda x: x.distance)

    # Select the top matches (you can adjust this threshold)
    num_matches = int(len(matches) * 0.15)
    matches = matches[:num_matches]

    # Extract the matched keypoints
    points1 = np.float32([keypoints1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
    points2 = np.float32([keypoints2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)

    # Estimate the perspective transformation
    M, mask = cv2.findHomography(points1, points2, cv2.RANSAC, 5.0)

    # Warp the first image onto the second image
    h, w = gray1.shape
    warped_img = cv2.warpPerspective(img1, M, (w, h))

    # Calculate the overlapping area
    overlapping_area = cv2.bitwise_and(warped_img, img1)
    extract_color_boundary(overlapping_area, img1)

    # Display the overlapping area
    cv2.imshow("Overlapping Area", overlapping_area)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # store_img(overlapping_area, store_img_path)


def find_overlapping_area(img_1, img_2):
    img1 = cv2.imread(img_1, cv2.IMREAD_GRAYSCALE)  # referenceImage
    img2 = cv2.imread(img_2, cv2.IMREAD_GRAYSCALE)  # sensedImage

    # img1 = cv2.imread(r"/home/angli19/Downloads/Panorama_Stitching-master/data/inp/examples/backyard1.jpg", cv2.IMREAD_GRAYSCALE)
    # img2 = cv2.imread(r"/home/angli19/Downloads/Panorama_Stitching-master/data/inp/examples/backyard2.jpg", cv2.IMREAD_GRAYSCALE)

    corrList, pos_1, pos_2 = findMatchFeatures(img1, img2, fundamental_file_name=img_1[img_1.rfind(r"/") + 1:img_1.rfind(r".")])
    # corrList, pos_1, pos_2 = findMatchFeatures_ORB(img1, img2)
    # pos_array = np.array(pos_1)

    # Find top-left point
    top_left = min(pos_1)

    # Find top-right point
    top_right = max(pos_1, key=lambda p: (p[1], -p[0]))

    # Find bottom-right point
    bottom_right = max(pos_1)

    # Find bottom-left point
    bottom_left = max(pos_1, key=lambda p: (-p[1], p[0]))


    img_1_copy = Image.fromarray(img1)
    draw = ImageDraw(img_1_copy)
    points_set = (top_left, top_right, bottom_left, bottom_right)

    # points_set = (tuple(top_left), tuple(top_right), tuple(bottom_left), tuple(bottom_right))
    # draw.polygon(points_set, outline="yellow")
    # draw.line((tuple(top_left), tuple(top_right)), width=5, fill=r"red")
    # draw.line((tuple(top_right), tuple(bottom_right)), width=5, fill=r"red")
    # draw.line((tuple(bottom_right), tuple(bottom_left)), width=5, fill=r"red")
    # draw.line((tuple(bottom_left), tuple(top_left)), width=5, fill=r"red")

    # draw.line((top_left, top_right), width=5, fill=r"red")
    # draw.line((top_right,bottom_right), width=5, fill=r"red")
    # draw.line((bottom_right, bottom_left), width=5, fill=r"red")
    # draw.line((bottom_left, top_left), width=5, fill=r"red")

    # # Display the result
    # modified_image = cv2.cvtColor(np.array(img_1_copy), cv2.COLOR_RGB2BGR)
    # cv2.imshow("Overlapping Region", modified_image)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    homography, inliersList = ransacHomography(corrList, 0.95)
    displayMatches(img1, img2, inliersList, "matches_SIFT_" + img_1[img_1.rfind(r"/") + 1:])
    # result = cv2.warpPerspective(img2, homography, (img1.shape[1], img1.shape[0]))
    # cv2.imwrite('transformed_img2.png', result)
    return top_left, top_right, bottom_left, bottom_right
    # img1 = cv2.imread(img_1, cv2.IMREAD_GRAYSCALE)  # referenceImage
    # img2 = cv2.imread(img_2, cv2.IMREAD_GRAYSCALE)  # sensedImage
    #
    # # Initiate AKAZE detector
    # akaze = cv2.AKAZE_create()
    # # Find the keypoints and descriptors with SIFT
    # kp1, des1 = akaze.detectAndCompute(img1, None)
    # kp2, des2 = akaze.detectAndCompute(img2, None)
    #
    # # BFMatcher with default params
    # bf = cv2.BFMatcher()
    # matches = bf.knnMatch(des1, des2, k=2)
    #
    # # Apply ratio test
    # good_matches = []
    # for m, n in matches:
    #     if m.distance < 0.75 * n.distance:
    #         good_matches.append([m])
    #
    # # Draw matches
    # img3 = cv2.drawMatchesKnn(img1, kp1, img2, kp2, good_matches, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
    # cv2.imwrite('matches.jpg', img3)
    #
    # # Select good matched keypoints
    # ref_matched_kpts = np.float32([kp1[m[0].queryIdx].pt for m in good_matches])
    # sensed_matched_kpts = np.float32([kp2[m[0].trainIdx].pt for m in good_matches])
    #
    # # Compute homography
    # H, status = cv2.findHomography(sensed_matched_kpts, ref_matched_kpts, cv2.RANSAC, 5.0)
    #
    # # Warp image
    # warped_image = cv2.warpPerspective(img2, H, (img2.shape[1], img2.shape[0]))
    #
    # cv2.imwrite('warped.jpg', warped_image)

    pass

    # # Open the image files.
    # img1_color = cv2.imread(img_1)  # Image to be aligned.
    # img2_color = cv2.imread(img_2)  # Reference image.
    #
    # height, width = img2_color.shape[0], img2_color.shape[1]
    #
    # sift = cv2.SIFT_create()
    # bf = cv2.BFMatcher()
    #
    # # Detect and match the features in the two images
    # kp1, des1 = sift.detectAndCompute(img1_color, None)
    # kp2, des2 = sift.detectAndCompute(img1_color, None)
    # matches = bf.knnMatch(des1, des2, k=2)
    #
    # # Filter the matches based on the Lowe's ratio test
    # good_matches = []
    # for m, n in matches:
    #     if m.distance < 0.75 * n.distance:
    #         good_matches.append(m)
    #
    # # Estimate the homography matrix using the RANSAC algorithm
    # MIN_MATCH_COUNT = 10
    # if len(good_matches) >= MIN_MATCH_COUNT:
    #     src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    #     dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    #     H, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
    #     image2_aligned = cv2.warpPerspective(img2_color, H, (width, height))
    #
    # # Subtract the two images to get the difference
    # diff = cv2.absdiff(img1_color, image2_aligned)
    #
    # # Threshold the difference to get the overlapping region
    # threshold = 30
    # gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    # ret, overlapping_region = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
    #
    # # Compute the size of the overlapping region
    # size = cv2.countNonZero(overlapping_region)
    #
    # # Compute the location of the overlapping region
    # x, y, w, h = cv2.boundingRect(overlapping_region)
    # xmin, ymin = x, y
    # xmax, ymax = x + w, y + h
    #
    # # Create a copy of one of the images
    # image1_copy = img1_color.copy()
    #
    # # Draw a rectangle around the overlapping region
    # cv2.rectangle(image1_copy, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
    #
    # # Display the result
    # cv2.imshow("Overlapping Region", image1_copy)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    # pass

    # # Convert to grayscale.
    # img1 = cv2.cvtColor(img1_color, cv2.COLOR_BGR2GRAY)
    # img2 = cv2.cvtColor(img2_color, cv2.COLOR_BGR2GRAY)
    # height, width = img2.shape
    #
    # # Create ORB detector with 5000 features.
    # orb_detector = cv2.ORB_create(5000)
    #
    # # Find keypoints and descriptors.
    # # The first arg is the image, second arg is the mask
    # #  (which is not required in this case).
    # kp1, d1 = orb_detector.detectAndCompute(img1, None)
    # kp2, d2 = orb_detector.detectAndCompute(img2, None)
    #
    # # Match features between the two images.
    # # We create a Brute Force matcher with
    # # Hamming distance as measurement mode.
    # matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    #
    # # Match the two sets of descriptors.
    # matches = matcher.match(d1, d2)
    #
    # # Sort matches on the basis of their Hamming distance.
    # # matches.sort(key=lambda x: x.distance)
    # matches = sorted(matches, key=lambda x: x.distance)
    # # Take the top 90 % matches forward.
    # matches = matches[:int(len(matches) * 0.9)]
    # no_of_matches = len(matches)
    #
    # # Define empty matrices of shape no_of_matches * 2.
    # p1 = np.zeros((no_of_matches, 2))
    # p2 = np.zeros((no_of_matches, 2))
    #
    # for i in range(len(matches)):
    #     p1[i, :] = kp1[matches[i].queryIdx].pt
    #     p2[i, :] = kp2[matches[i].trainIdx].pt
    #
    # # Find the homography matrix.
    # homography, mask = cv2.findHomography(p1, p2, cv2.RANSAC)
    #
    # # Use this matrix to transform the
    # # colored image wrt the reference image.
    # transformed_img = cv2.warpPerspective(img1_color,
    #                                       homography, (width, height))
    #
    # cv2.imshow('image',transformed_img)
    # pass
    # Save the output.
    # cv2.imwrite(output_file_name, transformed_img)

    # # Read in the two images and convert them to tensors
    #
    # img_ref = ToTensor()(Image.open(img_1).convert('L')).unsqueeze(0)
    # img_target = ToTensor()(Image.open(img_2).convert('L')).unsqueeze(0)
    #
    # # Compute the correlation map
    # corr_map = F.conv2d(img_ref, img_target.flip(-1).flip(-2))
    #
    # # Find the location of the maximum correlation
    # _, idx = torch.max(corr_map.view(-1), dim=0)
    # y, x = torch.div(idx, corr_map.shape[-1])
    #
    # # Compute the overlapping region
    # h, w = img_ref.shape[-2:]
    # xmin = int(torch.max(torch.tensor([0, x - w // 2])))
    # xmax = int(torch.min(torch.tensor([img_ref.shape[-1], x + w // 2])))
    # ymin = int(torch.max(torch.tensor([0, y - h // 2])))
    # ymax = int(torch.min(torch.tensor([img_ref.shape[-2], y + h // 2])))
    #
    # # Draw the overlapping region on the reference image
    # img_ref = ToPILImage()(img_ref.squeeze())
    # draw = ImageDraw.Draw(img_ref)
    # draw.rectangle([(xmin, ymin), (xmax, ymax)], outline='green')
    #
    # # Display the result
    # img_ref.show()


def store_img(img, path):
    print("store image into " + path)
    cv2.imwrite(path, img)

