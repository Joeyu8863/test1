import os

from my_utils.RawImageDataset import RawImageDataset
from my_utils.Data_Manipulation import Data_Manipulation

from my_utils import Constants



def Manipulate_img_pipeline(raw_data_path_name, manipulation_type, output_dataset_folder_name, rotation_angle=0):
    raw_images_dataset = RawImageDataset(raw_data_path_name)
    raw_data_mani = Data_Manipulation(raw_images_dataset, output_dataset_folder_name)

    if Constants.IMG_ROTATION == manipulation_type:
        raw_data_mani.rotate_all_img(rot_degree=rotation_angle)
    elif Constants.IMG_HORIZONTAL_FLIPPING == manipulation_type:
        raw_data_mani.flip_horizontal_all_img()
    elif Constants.IMG_AFFINE_TRANSFORMATION == manipulation_type:
        raw_data_mani.random_affine_transformation_all_img()
    elif Constants.IMG_CROPPING_RESIZE == manipulation_type:
        raw_data_mani.random_crop_resize_all_img()
    elif Constants.IMG_GAUSSIAN_BLURRING == manipulation_type:
        raw_data_mani.gaussian_blur_all_img()
    elif Constants.IMG_COLOR_JITTER == manipulation_type:
        raw_data_mani.random_color_jitter_all_img()
    elif Constants.IMG_GRAYSCALE == manipulation_type:
        raw_data_mani.grayscale_all_img()
    else:
        print("Cannot recognize the manipulation type, please check it again")
        exit(-1)


# def Img_rotate_pipeline(dataset_path_name, input_data_folder_name, output_data_folder_name,
#                         input_dataset_folder_name, output_dataset_folder_name, img_idx, rot_angle,
#                         modified_patch_row=0, modified_patch_col=0, patch_size = 100):
#     ## get raw dataset
#     raw_tra_images_dataset = RawImageDataset(dataset_path_name, input_data_folder_name, input_dataset_folder_name)
#     raw_data_mani = Data_Manipulation(raw_tra_images_dataset,
#                                       os.path.join(dataset_path_name, output_data_folder_name))
#
#     # raw_data_mani.rotate_img(0)
#     ## for block_3_part_1, modify image 506 (index: 12) and 570 (index:13)
#
#     raw_data_mani.rotate_img_patch(img_idx, modified_patch_row, modified_patch_col, rot_angle, patch_size=patch_size)