import numpy as np
from scipy.interpolate import interp1d
from scipy.optimize import brentq
from sklearn.metrics import roc_curve, roc_auc_score, auc
import matplotlib.pyplot as plt

FIG_SIZE = [14.4,10.8]
FIG_TICK_FONT_SIZE = 41
AXIS_LABEL_FONT_SIZE = 46
FIG_LEGEND_FONT_SIZE = 32
def show_result(file_name, out_file_name, is_authentic=1):
    # True results and predicted results (probabilities or scores)
    predicted_results = np.load(file_name, allow_pickle=True)

    if 1 == is_authentic:
        true_results = np.ones(predicted_results.shape)
    else:
        true_results = np.zeros(predicted_results.shape)

    # Compute ROC curve
    fpr, tpr, thresholds = roc_curve(true_results, predicted_results)
    plt.figure(figsize=FIG_SIZE)
    # Plot ROC curve
    plt.plot(fpr, tpr, color='blue', label='ROC Curve')

    # Random Guess line
    plt.plot([0, 1], [0, 1], color='red', linestyle='--', label='Random Guess')

    # Calculate EER
    eer_threshold = thresholds[np.argmin(np.abs(tpr - (1 - fpr)))]
    eer = fpr[np.abs(thresholds - eer_threshold).argmin()]
    plt.scatter(fpr[np.argmin(np.abs(tpr - (1 - fpr)))], tpr[np.argmin(np.abs(tpr - (1 - fpr)))],
                color='green', label='EER ({:.2f})'.format(eer))
    plt.plot([0, fpr[np.argmin(np.abs(tpr - (1 - fpr)))]], [tpr[np.argmin(np.abs(tpr - (1 - fpr)))],
                                                            tpr[np.argmin(np.abs(tpr - (1 - fpr)))]], color='green',
             linestyle='--')
    plt.plot([fpr[np.argmin(np.abs(tpr - (1 - fpr)))]], [tpr[np.argmin(np.abs(tpr - (1 - fpr)))]],
             marker='o', markersize=5, color='green')

    # Set labels and title
    plt.xlabel('False Positive Rate (FPR)')
    plt.ylabel('True Positive Rate (TPR)')
    plt.title('Receiver Operating Characteristic (ROC) Curve')

    # Set plot limits
    plt.xlim([0, 1])
    plt.ylim([0, 1])

    # Add legend
    plt.legend()
    plt.savefig(out_file_name, format='eps')

    # Display the plot
    plt.show()


def plot_roc(pos_file_name, neg_file_name, out_file_name="", is_authentic=1, index=0):
    # True results and predicted results (probabilities or scores)
    if r"45" in neg_file_name:
        pred_neg_value = list((~np.load(neg_file_name, allow_pickle=True).astype(bool)).astype(int))
    else:
        pred_neg_value = list(np.load(neg_file_name, allow_pickle=True))

    pred_pos_value = list(np.load(pos_file_name, allow_pickle=True))

    # pred_value = np.concatenate(pred_pos_value, pred_neg_value)
    pred_value = pred_pos_value + pred_neg_value
    true_pos_label = list(np.ones(len(pred_pos_value)))
    true_neg_label = list(np.zeros(len(pred_neg_value)))
    # true_label = np.concatenate(true_pos_label, true_neg_label)
    true_label = true_pos_label + true_neg_label
    # pred_value = pred_value - 0.01
    # pred_value[pred_value == 1] = 0.6
    # pred_value[pred_value == 0] = 0.3
    # if 1 == is_authentic:
    #     true_label = np.ones(pred_value.shape)
    # else:
    #     true_label = np.zeros(pred_value.shape)

    if 0 == index:
        fpr, tpr, _ = roc_curve(list(true_label[:]), list(pred_value[:]))
    else:
        fpr, tpr, _ = roc_curve(true_label[index], pred_value[index])
    roc_auc = auc(fpr, tpr)
    eer = brentq(lambda x: 1. - x - interp1d(fpr, tpr)(x), 0., 1.)
    plt.figure(figsize=FIG_SIZE)

    output_label = 'AUC = %0.3f, EER = %0.3f'
    plt.plot(fpr, tpr, color='blue',
             label=output_label % (roc_auc,eer), linewidth=6)
    # plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.0])
    plt.xticks(fontsize=FIG_TICK_FONT_SIZE)
    plt.yticks(fontsize=FIG_TICK_FONT_SIZE)
    plt.xlabel('FPR', fontsize=AXIS_LABEL_FONT_SIZE)
    plt.ylabel('TPR', fontsize=AXIS_LABEL_FONT_SIZE)
    # plt.title('Receiver operating characteristic example')
    leg = plt.legend(loc="lower right", fontsize=FIG_LEGEND_FONT_SIZE)
    leg.get_lines()[0].set_linewidth(6)
    # leg.get_lines()[1].set_linewidth(6)
    ax = plt.gca()
    yticks = ax.yaxis.get_major_ticks()
    yticks[0].label1.set_visible(False)

    if "" != out_file_name:
        plt.savefig(out_file_name + '.eps', format='eps', dpi=1200)

    plt.show()
    pass