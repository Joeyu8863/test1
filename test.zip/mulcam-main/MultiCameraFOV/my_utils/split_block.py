import json
import os.path
import shutil
from os.path import exists


def split_block():
    file_dir = r"/home/angli19/data/img_data_zip"
    json_file_name = os.path.join(file_dir, r"split_block_train.json")
    img_file_dir = os.path.join(file_dir, r"rgbs")
    extension_name = r".png"

    with open(json_file_name, 'r') as json_file:
        jcc_data = json.load(json_file)
        for block_name in jcc_data:
            img_name_list = jcc_data[block_name]['elements']
            if not os.path.exists(os.path.join(file_dir, block_name)):
                os.mkdir(os.path.join(file_dir, r"blocks", block_name))
            for img_name in img_name_list:
                cur_img_file_name = os.path.join(img_file_dir, img_name[0] + extension_name)
                new_img_file_name = os.path.join(file_dir, r"blocks", block_name, str(img_name[1]) + extension_name)
                if exists(cur_img_file_name):
                    shutil.move(cur_img_file_name, new_img_file_name)
                else:
                    pass
        pass
