'''
    1) findFeatures FUNCTION- finding keyPoints using opencv.
    2) matchFeatures FUNCTION - output: a set of points coordinates in both images, of size nx2
                        (that most likely matched, including outliers).
    3) applyHomography FUNCTION
    4) leastSquareHomography
    5) ransacHomography FUNCTION
'''

from __future__ import print_function

import os.path

import cv2 as cv
import numpy as np
import random
import argparse
import matplotlib.pyplot as plt

from my_utils import plot_utils


matches = []
pos1 = []
pos2 = []


## SURF cannot be implemented due to SURF is a patented algorithm, use SIFT instead
def findMatchFeatures_SURF(img1, img2):
    # Load the two images
    # img1 = cv.imread(img1)
    # img2 = cv.imread(img2)

    # # Convert images to grayscale
    # gray1 = cv.cvtColor(img1, cv.COLOR_BGR2GRAY)
    # gray2 = cv.cvtColor(img2, cv.COLOR_BGR2GRAY)

    # Detect keypoints and compute descriptors using ORB
    ## SURF cannot be implemented due to SURF is a patented algorithm, use SIFT instead

    surf = cv.xfeatures2d.SURF_create()
    keypoints1, descriptors1 = surf.detectAndCompute(img1, None)
    keypoints2, descriptors2 = surf.detectAndCompute(img2, None)

    # Match keypoints between the two images using FLANN
    matcher = cv.DescriptorMatcher_create(cv.DESCRIPTOR_MATCHER_BRUTEFORCE)
    matches = matcher.match(descriptors1, descriptors2)

    min_dist = 80
    corrList = []
    for match in matches:
        if match.distance < min_dist:  # more accurate is doing:  match.distance <  2* min_dist
            img1_idx = match.queryIdx
            img2_idx = match.trainIdx
            [x1, y1] = keypoints1[img1_idx].pt
            [x2, y2] = keypoints2[img2_idx].pt
            corrList.append([x1, y1, x2, y2])
            pos1.append([x1, y1])  # save for display lines
            pos2.append([x2, y2])  # save for display lines

    return corrList, pos1, pos2


def calculate_sampson_distance(F1, F2, correspondences):
    num_correspondences = correspondences.shape[0]
    distances = np.zeros(num_correspondences)

    for i in range(num_correspondences):
        x1 = correspondences[i, :3]  # Homogeneous coordinates of point x1
        x2 = correspondences[i, 3:]  # Homogeneous coordinates of point x2

        # Calculate the numerator and denominator of the Sampson distance formula
        numerator = (np.dot(x2, np.dot(F1, x1))) ** 2
        denominator = np.linalg.norm(np.dot(F1, x1)[:2]) ** 2 + np.linalg.norm(np.dot(F2.T, x2)[:2]) ** 2

        # Calculate the Sampson distance
        distances[i] = numerator / denominator

    return distances


def findMatchFeatures_ORB(img1, img2):
    # Load the two images
    # img1 = cv.imread(img1)
    # img2 = cv.imread(img2)

    # # Convert images to grayscale
    # gray1 = cv.cvtColor(img1, cv.COLOR_BGR2GRAY)
    # gray2 = cv.cvtColor(img2, cv.COLOR_BGR2GRAY)

    # Detect keypoints and compute descriptors using ORB
    orb = cv.ORB_create()
    keypoints1, descriptors1 = orb.detectAndCompute(img1, None)
    keypoints2, descriptors2 = orb.detectAndCompute(img2, None)

    # Match keypoints between the two images using FLANN
    bf = cv.BFMatcher(cv.NORM_HAMMING, crossCheck=True)
    # Match descriptors.
    matches = bf.match(descriptors1, descriptors2)

    # matcher = cv.DescriptorMatcher_create(cv.DESCRIPTOR_MATCHER_BRUTEFORCE_HAMMING)
    # matches = matcher.match(descriptors1, descriptors2)

    matches_temp = sorted(matches, key=lambda x: x.distance)

    min_dist = 100
    corrList = []

    # for i in range(0, 5):
    #     img1_idx = matches_temp[i].queryIdx
    #     img2_idx = matches_temp[i].trainIdx
    #     [x1, y1] = keypoints1[img1_idx].pt
    #     [x2, y2] = keypoints2[img2_idx].pt
    #     corrList.append([x1, y1, x2, y2])
    #     pos1.append([x1, y1])  # save for display lines
    #     pos2.append([x2, y2])

    for match in matches:
        if match.distance < min_dist:  # more accurate is doing:  match.distance <  2* min_dist
            img1_idx = match.queryIdx
            img2_idx = match.trainIdx
            [x1, y1] = keypoints1[img1_idx].pt
            [x2, y2] = keypoints2[img2_idx].pt
            corrList.append([x1, y1, x2, y2])
            pos1.append([x1, y1])  # save for display lines
            pos2.append([x2, y2])  # save for display lines

    return corrList, pos1, pos2


def evaluateRealtimeFundamentalMatrix(authentic_f, img_list_1, img_list_2, dataset_name, cur_camera,
                                      neighbor_camera, is_store=1, is_authentic_dataset=1, label_file_name_part=""):
    # -- Step 1: Detect the keypoints using SIFT Detector, compute the descriptors
    fundamental_matrix_list = []
    home_directory = os.path.expanduser('~')
    fundamental_matrix_dir = r"data/fundamental_matrix"
    out_fundamental_matrix_file_name = os.path.join(home_directory, fundamental_matrix_dir, dataset_name,
                                                    r"fundamental_matrix_list_" + cur_camera + "_" +
                                                    neighbor_camera + "_" + label_file_name_part + r".npy")
    out_label_file_name = os.path.join(home_directory, fundamental_matrix_dir, dataset_name,
                                                    r"label_list_" + cur_camera + "_" +
                                                    neighbor_camera + "_" + label_file_name_part + r".npy")

    fundamental_matrix_list = []
    average_distance_list = []
    label_list = []
    for cur_img, cur_neighbor_img in zip(img_list_1, img_list_2):
        if cur_img[cur_img.rfind(r"/") + 1:cur_img.rfind(r".")] == \
                cur_neighbor_img[cur_neighbor_img.rfind(r"/") + 1:cur_neighbor_img.rfind(r".")]:

            print("calculate fundamental matrix between " + cur_img[cur_img.rfind(r"/") + 1:cur_img.rfind(r".")])
            cur_img_matrix = cv.imread(cur_img, cv.IMREAD_GRAYSCALE)  # referenceImage
            cur_neighbor_img_matrix = cv.imread(cur_neighbor_img, cv.IMREAD_GRAYSCALE)

            detector = cv.xfeatures2d.SIFT_create()  # (0, 3, 0)
            # detector = cv.xfeatures2d_SURF.create (hessianThreshold=minHessian)
            keypoints1, descriptors1 = detector.detectAndCompute(cur_img_matrix, None)
            keypoints2, descriptors2 = detector.detectAndCompute(cur_neighbor_img_matrix, None)

            # -- Step 2: Matches features given a list of keypoints, descriptors, & images with a Brute-Force based matcher
            # Since SIFT is a floating-point descriptor NORM_L2 is used
            matcher = cv.BFMatcher(cv.NORM_L2, True)  #
            matches = matcher.match(descriptors1, descriptors2)
            matches_temp = sorted(matches, key=lambda x: x.distance)
            # -- Filter matches using the Lowe's ratio test
            min_dist = 30  # 80
            corrList = []
            corrList_homo = []
            distance_list = []

            min_corresponding_point = 56

            for i in range(0, min(min_corresponding_point, len(matches_temp))):
                img1_idx = matches_temp[i].queryIdx
                img2_idx = matches_temp[i].trainIdx
                [x1, y1] = keypoints1[img1_idx].pt
                [x2, y2] = keypoints2[img2_idx].pt
                corrList.append([x1, y1, x2, y2])
                corrList_homo.append([x1, y1, 1, x2, y2, 1])
                pos1.append([x1, y1])  # save for display lines
                pos2.append([x2, y2])

                # if 0 != i and 0 == i % 7:
                #     fundamental_matrix, _ = cv.findFundamentalMat(np.float32(pos1), np.float32(pos2),
                #                                                   cv.FM_RANSAC)
                #     fundamental_matrix_list.append(fundamental_matrix)

            fundamental_matrix, _ = cv.findFundamentalMat(np.float32(pos1), np.float32(pos2),
                                                          cv.FM_RANSAC)  # cv.FM_LMEDS cv.FM_RANSAC)

            distances = calculate_sampson_distance(authentic_f, fundamental_matrix, np.array(corrList_homo))
            average_distance = np.mean(distances)

            # print("Sampson distances:", distances)
            # print("Average distance:", average_distance)
            average_distance_list.append(average_distance)

            if 1 == is_authentic_dataset:
                if average_distance < 500:
                    label_list.append(1)
                else:
                    label_list.append(0)
            else:
                if average_distance >= 500:
                    label_list.append(0)
                else:
                    label_list.append(1)
            fundamental_matrix_list.append(fundamental_matrix)
        else:
            pass
    # plot_sampson_distance(average_distance_list)
    # plot_sampson_distance_hist(average_distance_list)
    if 1 == is_store:
        print("save the fundamental matrix of " + cur_camera + " and " + neighbor_camera + " into " +
              out_fundamental_matrix_file_name)
        np.save(out_fundamental_matrix_file_name, np.array(fundamental_matrix_list, dtype=object),
                allow_pickle=True)

        print("save the fundamental matrix of " + cur_camera + " and " + neighbor_camera + " into " +
              out_label_file_name)
        np.save(out_label_file_name, np.array(label_list, dtype=object),
                allow_pickle=True)
    return out_fundamental_matrix_file_name


def findFundamentalMatrix(img_list_1, img_list_2, dataset_name, cur_camera, neighbor_camera,
                          attack_type=r"", is_store=1):
    # -- Step 1: Detect the keypoints using SIFT Detector, compute the descriptors
    fundamental_matrix_list = []
    home_directory = os.path.expanduser('~')
    fundamental_matrix_dir = r"data/fundamental_matrix"
    out_fundamental_matrix_file_name = os.path.join(home_directory, fundamental_matrix_dir, dataset_name,
                                                    r"fundamental_matrix_list_" + cur_camera + "_" +
                                                    neighbor_camera + r"_" + attack_type + r".npy")
    fundamental_matrix_list = []
    for cur_img, cur_neighbor_img in zip(img_list_1, img_list_2):
        if cur_img[cur_img.rfind(r"/") + 1:cur_img.rfind(r".")] == \
                cur_neighbor_img[cur_neighbor_img.rfind(r"/") + 1:cur_neighbor_img.rfind(r".")]:

            print("calculate fundamental matrix between " + cur_img[cur_img.rfind(r"/") + 1:cur_img.rfind(r".")])
            cur_img_matrix = cv.imread(cur_img, cv.IMREAD_GRAYSCALE)  # referenceImage
            cur_neighbor_img_matrix = cv.imread(cur_neighbor_img, cv.IMREAD_GRAYSCALE)

            detector = cv.xfeatures2d.SIFT_create()  # (0, 3, 0)
            # detector = cv.xfeatures2d_SURF.create (hessianThreshold=minHessian)
            keypoints1, descriptors1 = detector.detectAndCompute(cur_img_matrix, None)
            keypoints2, descriptors2 = detector.detectAndCompute(cur_neighbor_img_matrix, None)

            # -- Step 2: Matches features given a list of keypoints, descriptors, & images with a Brute-Force based matcher
            # Since SIFT is a floating-point descriptor NORM_L2 is used
            matcher = cv.BFMatcher(cv.NORM_L2, True)  #
            matches = matcher.match(descriptors1, descriptors2)
            matches_temp = sorted(matches, key=lambda x: x.distance)
            # -- Filter matches using the Lowe's ratio test
            min_dist = 30  # 80
            corrList = []
            corrList_homo = []
            distance_list = []

            min_corresponding_point = 56
            for i in range(0, min_corresponding_point):
                img1_idx = matches_temp[i].queryIdx
                img2_idx = matches_temp[i].trainIdx
                [x1, y1] = keypoints1[img1_idx].pt
                [x2, y2] = keypoints2[img2_idx].pt
                corrList.append([x1, y1, x2, y2])
                corrList_homo.append([x1, y1, 1, x2, y2, 1])
                pos1.append([x1, y1])  # save for display lines
                pos2.append([x2, y2])

                # if 0 != i and 0 == i % 7:
                #     fundamental_matrix, _ = cv.findFundamentalMat(np.float32(pos1), np.float32(pos2),
                #                                                   cv.FM_RANSAC)
                #     fundamental_matrix_list.append(fundamental_matrix)

            fundamental_matrix, _ = cv.findFundamentalMat(np.float32(pos1), np.float32(pos2),
                                                          cv.FM_RANSAC)  # cv.FM_LMEDS cv.FM_RANSAC)

            if len(fundamental_matrix_list) > 2:
                distances = calculate_sampson_distance(np.mean(fundamental_matrix_list, axis=0), fundamental_matrix,
                                                       np.array(corrList_homo))
                average_distance = np.mean(distances)

                # print("Sampson distances:", distances)
                print("Average distance:", average_distance)
            fundamental_matrix_list.append(fundamental_matrix)
        else:
            pass
    if 1 == is_store:
        print(
            "save the fundamental matrix of " + cur_camera + " and " + neighbor_camera + " into " + out_fundamental_matrix_file_name)
        np.save(out_fundamental_matrix_file_name, np.array(fundamental_matrix_list, dtype=object),
                allow_pickle=True)
    return out_fundamental_matrix_file_name


def findMatchFeatures(img1, img2, fundamental_file_name=r""):
    # global matches, pos1, pos2

    # -- Step 1: Detect the keypoints using SIFT Detector, compute the descriptors
    detector = cv.xfeatures2d.SIFT_create()  # (0, 3, 0)
    # detector = cv.xfeatures2d_SURF.create (hessianThreshold=minHessian)
    keypoints1, descriptors1 = detector.detectAndCompute(img1, None)
    keypoints2, descriptors2 = detector.detectAndCompute(img2, None)

    # -- Step 2: Matches features given a list of keypoints, descriptors, & images with a Brute-Force based matcher
    # Since SIFT is a floating-point descriptor NORM_L2 is used
    matcher = cv.BFMatcher(cv.NORM_L2, True)  #
    matches = matcher.match(descriptors1, descriptors2)
    matches_temp = sorted(matches, key=lambda x: x.distance)
    # -- Filter matches using the Lowe's ratio test
    min_dist = 30  # 80
    corrList = []
    distance_list = []
    fundamental_matrix_list = []
    min_corresponding_point = 56
    for i in range(0, min_corresponding_point):
        img1_idx = matches_temp[i].queryIdx
        img2_idx = matches_temp[i].trainIdx
        [x1, y1] = keypoints1[img1_idx].pt
        [x2, y2] = keypoints2[img2_idx].pt
        corrList.append([x1, y1, x2, y2])
        pos1.append([x1, y1])  # save for display lines
        pos2.append([x2, y2])

        # if 0 != i and 0 == i % 7:
        #     fundamental_matrix, _ = cv.findFundamentalMat(np.float32(pos1), np.float32(pos2),
        #                                                   cv.FM_RANSAC)
        #     fundamental_matrix_list.append(fundamental_matrix)

    # np.save(os.path.join(r"/home/angli19/data/fundamental_matrix", r"fundamental_matrix_list_" +
    #                      fundamental_file_name + ".npy"), np.array(fundamental_matrix_list, dtype=object),
    #                       allow_pickle=True)
    # for match in matches:
    #     distance_list.append(match.distance)
    #     if match.distance <= min_dist:  #  and match.distance >= 60 more accurate is doing:  match.distance <  2* min_dist
    #         img1_idx = match.queryIdx
    #         img2_idx = match.trainIdx
    #         [x1, y1] = keypoints1[img1_idx].pt
    #         [x2, y2] = keypoints2[img2_idx].pt
    #         corrList.append([x1, y1, x2, y2])
    #         pos1.append([x1, y1])  # save for display lines
    #         pos2.append([x2, y2])  # save for display lines

    # plt.hist(distance_list, bins=20)
    # plt.xlabel('Value')
    # plt.ylabel('Frequency')
    # plt.title('Data Distribution')
    # plt.show()
    fundamental_matrix, _ = cv.findFundamentalMat(np.float32(pos1), np.float32(pos2),
                                                  cv.FM_RANSAC)  # cv.FM_LMEDS cv.FM_RANSAC)
    return corrList, pos1, pos2


def applyHomography(corrList, h):
    #  transforms pos1 points (from image 1) to pos2 using the homography we found
    #  returns all estimated transposed points (from image 1 to image 2 using homography)
    estimatedPos2 = []
    for i in range(len(corrList)):  # corr[i] -> [x1,y1,x'1,y'1]
        p1 = np.transpose([corrList[i][0], corrList[i][1], 1])  # p1 = transpose(x1,y1,1) -> homogenic point
        estimateP1 = np.dot(h, p1)  # [x2~,y2~,z2~] = h * p1
        estimateP2 = (1 / estimateP1[2]) * estimateP1  # dividing by the third element
        estimatedPos2.append([estimateP2[0], estimateP2[1]])  # adding estimated point (x1,y1)

    return estimatedPos2


def geometricDistance(corrList, h, inlierTol):
    #  computes
    inliers = []
    estimatedPos2 = applyHomography(corrList, h)

    for i in range(len(corrList)):
        p2 = np.transpose([corrList[i][2], corrList[i][3], 1])
        estimateP2 = np.transpose([estimatedPos2[i][0], estimatedPos2[i][1], 1])

        error = p2 - estimateP2
        error = np.linalg.norm(error)

        if error < inlierTol:
            inliers.append(corrList[i])
    return inliers


def calculateHomography(randomFour):
    # loop through correspondences and create assemble matrix
    aList = []
    for r in randomFour:
        p1 = [r[0], r[1], 1]  # 2 pairs of matched points
        p2 = [r[2], r[3], 1]  # 2 pairs of matched points ---> so we have 8 points
        a2 = [0, 0, 0, -p2[2] * p1[0], -p2[2] * p1[1], -p2[2] * p1[2],
              p2[1] * p1[0], p2[1] * p1[1], p2[1] * p1[2]]
        a1 = [-p2[2] * p1[0], -p2[2] * p1[1], -p2[2] * p1[2], 0, 0, 0,
              p2[0] * p1[0], p2[0] * p1[1], p2[0] * p1[2]]
        aList.append(a1)
        aList.append(a2)

    # svd composition (uses least square)
    u, s, v = np.linalg.svd(aList)

    # reshape the min singular value into a 3x3 matrix
    h = np.reshape(v[8], (3, 3))

    # normalize h
    h = (1 / h.item(8)) * h
    return h


def ransacHomography(corrList, threshold):
    maxInliers = []
    finalHomography = None

    for i in range(1000):
        # find 4 random points to calculate a homography
        corr1 = corrList[random.randrange(0, len(corrList))]
        corr2 = corrList[random.randrange(0, len(corrList))]
        randomFour = np.vstack((corr1, corr2))
        corr3 = corrList[random.randrange(0, len(corrList))]
        randomFour = np.vstack((randomFour, corr3))
        corr4 = corrList[random.randrange(0, len(corrList))]
        randomFour = np.vstack((randomFour, corr4))

        # finds the homography function for those points
        h = calculateHomography(randomFour)

        # NEED TO SEND P1 POINTS & H TO applyHomography, then calc Ej & inliers
        # runs over each pair of matched points [x1,y1,x'1,y'1]
        inliers = geometricDistance(corrList, h, 5)  # 10 why inlierTol is 5 ??

        if len(inliers) > len(maxInliers):
            maxInliers = inliers
            finalHomography = h

        if len(maxInliers) > (len(corrList) * threshold):
            break
    return finalHomography, maxInliers


'''
    ! displayMatches FUNCTION !

    runs on an image pair in each one of the provided sequences,
    together with its match points pos1 pos2 (obtained from findFeatures & matchFeatures),
    and inlier index set 'inlind' (obtained from ransacHomography).
    inliers -  blue line
    outliers - yellow line
'''


def displayMatches(img1, img2, inliers, fileName):
    matchImg = drawMatches(img1, img2, inliers)
    out_path = r"/home/angli19/data/mathces_pictures"
    cv.imwrite(os.path.join(out_path, fileName), matchImg)


def drawMatches(img1, img2, inliers):
    # Create a new output image that concatenates the two images together
    rows1 = img1.shape[0]
    cols1 = img1.shape[1]
    rows2 = img2.shape[0]
    cols2 = img2.shape[1]
    out = np.zeros((max([rows1, rows2]), cols1 + cols2, 3), dtype='uint8')

    # Place the first image to the left
    out[:rows1, :cols1, :] = np.dstack([img1, img1, img1])

    # Place the next image to the right of it
    out[:rows2, cols1:cols1 + cols2, :] = np.dstack([img2, img2, img2])
    counter = 0
    counter2 = 0
    # For each pair of points we have between both images
    # draw circles, then connect a line between them
    for i in range(len(pos1)):  # len(pos1)
        inlier = False

        if inliers is not None:
            for j in inliers:
                if j[0] == pos1[i][0] and j[1] == pos1[i][1] and j[2] == pos2[i][0] and j[3] == pos2[i][1]:
                    inlier = True
                    counter += 1

        # Draw a small circle at both co-ordinates
        cv.circle(out, (int(pos1[i][0]), int(pos1[i][1])), 4, (0, 0, 255), 1)
        cv.circle(out, (int(pos2[i][0]) + cols1, int(pos2[i][1])), 4, (0, 0, 255), 1)

        # Draw a line in between the two points, draw inliers if we have them
        if inliers is not None and inlier:
            cv.line(out, (int(pos1[i][0]), int(pos1[i][1])), (int(pos2[i][0]) + cols1, int(pos2[i][1])), (0, 255, 255),
                    1)

        elif inliers is not None:
            cv.line(out, (int(pos1[i][0]), int(pos1[i][1])), (int(pos2[i][0]) + cols1, int(pos2[i][1])), (255, 0, 0), 1)
            counter2 += 1
        if inliers is None:
            cv.line(out, (int(pos1[i][0]), int(pos1[i][1])), (int(pos2[i][0]) + cols1, int(pos2[i][1])), (0, 0, 0), 1)
    # print("inliers: " + str(counter))
    # print("outliers: " + str(counter2))
    return out
