import math
import os

import numpy as np
import torch
import torchvision.io
import torchvision.transforms as T
from PIL import Image
from patchify import patchify, unpatchify
from torch.utils.data import DataLoader
from torchvision.transforms.functional import get_image_size, rotate
from torchvision.transforms.functional import pil_to_tensor
from sklearn.feature_extraction import image
from torchvision.utils import save_image
from skimage import transform


class Data_Manipulation:
    def __init__(self, raw_dataset, output_folder_name=""):
        ## create raw dataset and dataloader
        self.mRaw_dataset = raw_dataset
        self.batch_size = 1
        self.mRaw_dataloader = DataLoader(self.mRaw_dataset, batch_size=self.batch_size)

        ## create output directory if not exist
        self.mOutput_folder_name = output_folder_name
        if not os.path.exists(self.mOutput_folder_name):
            os.makedirs(self.mOutput_folder_name)

    '''
    Time: 5/5/2023
    Rotate all image in the input folder
    '''
    def rotate_all_img(self, rot_degree=180):
        i = 1
        img_count = len(self.mRaw_dataloader) * self.batch_size
        print("Rotate " + str(img_count) + " images, rotation degree is " + str(rot_degree) + " degree")
        for cur_img, cur_file_name in self.mRaw_dataloader:
            # T.ToPILImage()(cur_img.squeeze(0)).show()
            print("rotate and save " + str(i) + " images: " + cur_file_name[0])
            rotated_img = self.rotate_img(cur_img.squeeze(0), rot_degree)
            # T.ToPILImage()(rotated_img).show()
            save_image(rotated_img.float(), os.path.join(self.mOutput_folder_name, cur_file_name[0]))
            i = i + 1

    '''
        Time: 5/6/2023
        Flip all image in the input folder
    '''
    def flip_horizontal_all_img(self):
        i = 1
        hflipper = T.RandomHorizontalFlip(p=1)
        img_count = len(self.mRaw_dataloader) * self.batch_size

        print("Flip " + str(img_count) + " images horizontally")
        for cur_img, cur_file_name in self.mRaw_dataloader:
            # T.ToPILImage()(cur_img.squeeze(0)).show()
            print("Horizontally flip and save " + str(i) + " images: " + cur_file_name[0])
            flipped_img = hflipper(cur_img.squeeze(0))
            # T.ToPILImage()(flipped_img).show()
            save_image(flipped_img.float(), os.path.join(self.mOutput_folder_name, cur_file_name[0]))
            i = i + 1

    '''
        Time: 5/5/2023
        Affine transform all image in the input folder
    '''
    def random_affine_transformation_all_img(self):
        i = 1
        img_count = len(self.mRaw_dataloader) * self.batch_size

        print("Random affine transform " + str(img_count) + " images")
        for cur_img, cur_file_name in self.mRaw_dataloader:
            # T.ToPILImage()(cur_img.squeeze(0)).show()
            print("Random affine transform and save " + str(i) + " images: " + cur_file_name[0])
            affine_transfomer = T.RandomAffine(degrees=(30, 70), translate=(0.1, 0.3), scale=(0.5, 0.75))
            affine_imgs = affine_transfomer(cur_img.squeeze(0))
            # T.ToPILImage()(flipped_img).show()
            save_image(affine_imgs.float(), os.path.join(self.mOutput_folder_name, cur_file_name[0]))
            i = i + 1

    '''
        Time: 5/8/2023
        Crop and resize all image in the input folder
    '''
    def random_crop_resize_all_img(self):
        i = 1
        img_count = len(self.mRaw_dataloader) * self.batch_size

        print("Random crop and resize " + str(img_count) + " images")
        for cur_img, cur_file_name in self.mRaw_dataloader:
            # T.ToPILImage()(cur_img.squeeze(0)).show()
            print("Random crop and resize, and save " + str(i) + " images: " + cur_file_name[0])
            resize_cropper = T.RandomResizedCrop(size=(cur_img.size()[2], cur_img.size()[3]), antialias=True)
            resized_crops_img = resize_cropper(cur_img.squeeze(0))
            # T.ToPILImage()(flipped_img).show()
            save_image(resized_crops_img.float(), os.path.join(self.mOutput_folder_name, cur_file_name[0]))
            i = i + 1

    '''
        Time: 5/8/2023
        Add Gaussian blur to all image in the input folder
    '''
    def gaussian_blur_all_img(self):
        i = 1
        img_count = len(self.mRaw_dataloader) * self.batch_size

        print("Gaussian blur " + str(img_count) + " images")
        for cur_img, cur_file_name in self.mRaw_dataloader:
            # T.ToPILImage()(cur_img.squeeze(0)).show()
            print("Gaussian blur and save " + str(i) + " images: " + cur_file_name[0])
            blurrer = T.GaussianBlur(kernel_size=(9, 9), sigma=(0.1, 5))
            blurred_img = blurrer(cur_img.squeeze(0))
            # T.ToPILImage()(flipped_img).show()
            save_image(blurred_img.float(), os.path.join(self.mOutput_folder_name, cur_file_name[0]))
            i = i + 1

    '''
        Time: 5/8/2023
        Add random color jitter (brightness, contrast, saturation and hue) to all image in the input folder
    '''
    def random_color_jitter_all_img(self):
        i = 1
        img_count = len(self.mRaw_dataloader) * self.batch_size

        print("Random color jitter " + str(img_count) + " images")
        for cur_img, cur_file_name in self.mRaw_dataloader:
            # T.ToPILImage()(cur_img.squeeze(0)).show()
            print("Random color jitter " + str(i) + " images: " + cur_file_name[0])
            jitter = T.ColorJitter(brightness=.5, hue=.3, contrast=0.7, saturation=0.5)
            jittered_img = jitter(cur_img.squeeze(0))
            # T.ToPILImage()(flipped_img).show()
            save_image(jittered_img.float(), os.path.join(self.mOutput_folder_name, cur_file_name[0]))
            i = i + 1

    '''
        Time: 5/8/2023
        Grayscale all image in the input folder
    '''
    def grayscale_all_img(self):
        i = 1
        img_count = len(self.mRaw_dataloader) * self.batch_size

        print("Grayscale " + str(img_count) + " images")
        for cur_img, cur_file_name in self.mRaw_dataloader:
            # T.ToPILImage()(cur_img.squeeze(0)).show()
            print("Grayscale " + str(i) + " images: " + cur_file_name[0])
            gray_img = T.Grayscale()(cur_img.squeeze(0))
            # T.ToPILImage()(gray_img).show()
            save_image(gray_img.float(), os.path.join(self.mOutput_folder_name, cur_file_name[0]))
            i = i + 1

    def rotate_img_id(self, idx, rot_degree=180):
        orig_img = T.ToPILImage()(self.mRaw_dataset[idx])
        orig_img.show()

        rotater = T.RandomRotation(degrees=rot_degree)
        rotated_img = rotater(orig_img)
        # rotated_img.show()

    def rotate_img(self, orig_img, rot_degree=180):
        # rotater = T.RandomRotation(degrees=rot_degree)
        # orig_img.show()
        # rotated_img = rotater(orig_img)

        rotated_img = rotate(orig_img, rot_degree)

        # orig_img.show()
        # rotated_img.show()
        return rotated_img

    def split_patches(self, idx, patch_height, patch_width):
        img_width = get_image_size(self.mRaw_dataset[idx])[0]
        img_height = get_image_size(self.mRaw_dataset[idx])[1]

        raw_img = self.mRaw_dataset[idx].permute(1, 2, 0).numpy()

        cur_step = patch_width
        patch_shape = (patch_height, patch_width, self.mRaw_dataset[idx].size()[0])

        raw_patches = np.array([])

        row_index = 0

        while row_index + patch_width <= img_height:
            cur_raw_patch = patchify(raw_img[row_index:row_index + patch_height, :, :],
                                     patch_shape, step=cur_step)
            if 0 != raw_patches.size:
                raw_patches = np.concatenate((raw_patches, cur_raw_patch), axis=0)
            else:
                raw_patches = cur_raw_patch
            row_index = row_index + patch_height

        return raw_patches

    def concate_img(self, idx, modified_img):
        raw_img_shapes = self.mRaw_dataset[idx].permute(1, 2, 0).shape
        modified_img_shapes = modified_img.shape

        raw_img_array = self.mRaw_dataset[idx].permute(1, 2, 0).numpy()

        new_img_array = raw_img_array

        new_img_array[0:modified_img_shapes[0], 0:modified_img_shapes[1], :] = modified_img

        return new_img_array

    def rotate_img_patch(self, idx, modified_patch_row, modified_patch_col, rot_degree=0, patch_size=300):
        # patch_number_raw = 3
        # patch_width = int(get_image_size(self.raw_dataset[idx])[0] / patch_number_raw)
        # patch_height = int(get_image_size(self.raw_dataset[idx])[1] / patch_number_raw)

        patch_width = patch_size
        patch_height = patch_size

        ## split it into a set of patches (patch_width X patch_heigth)
        raw_patches = self.split_patches(idx, patch_height, patch_width)
        output_patches = raw_patches

        # for i in range(raw_patches.shape[0]):
        #     for j in range(raw_patches.shape[1]):
        #         patch = raw_patches[i, j, 0]
        #         patch = Image.fromarray(patch)
        #         patch.show()

        # num = i * patches.shape[1] + j
        # patch.save(f"patch_{num}.jpg")
        # patch = patches[2, 3, 0]
        # patch = Image.fromarray(patch)
        # patch.show()

        # output_shape = (get_image_size(self.raw_dataset[idx])[1],
        #                 get_image_size(self.raw_dataset[idx])[0],
        #                 self.raw_dataset[idx].size()[0])
        ## change (2,3) for patch_size = 192 * 2 X 108 *2
        raw_patch_image = Image.fromarray(raw_patches[modified_patch_row, modified_patch_col, 0])
        # raw_patch_image.show()

        output_patches[modified_patch_row, modified_patch_col, 0] = np.asarray(
            self.rotate_img(raw_patch_image, rot_degree))
        # Image.fromarray(output_patches[1, 1, 0]).show()
        output_shape = (patch_height * output_patches.shape[0],
                        patch_width * output_patches.shape[1],
                        self.mRaw_dataset[idx].size()[0])

        ##
        # Image.fromarray(inter_output_image).show()
        if output_shape[0] < get_image_size(self.mRaw_dataset[idx])[1] or \
                output_shape[1] < get_image_size(self.mRaw_dataset[idx])[2]:
            output_image = self.concate_img(idx, unpatchify(output_patches, output_shape))
        else:
            output_image = unpatchify(output_patches, output_shape)

        Image.fromarray(output_image).show()

        # save_image(torch.from_numpy(output_image).permute(2,0,1),
        #            r"/home/angli19/data/image_data/modified_images/modified_block_3_part_1/Transamerica_Pyramid_0000.jpeg")
        # rot_patch_image = self.rotate_img(raw_patch_image, 90)
        # rot_patch_image.show()
        ## assigned the rotate image to the splitted patches
        # patches[2, 3, 0] = np.asarray(rot_patch_image)

        # Image.fromarray(patches[2, 3, 0]).show()

        print("break")
