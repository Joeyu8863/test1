import os
from torchvision.io import read_image
import torchvision.transforms as T
from PIL import Image
from RawImageDataset import RawImageDataset
import matplotlib.pyplot as plt
from torchvision.utils import save_image

## Get/Read image data from disk
class Get_Data:
    def __init__(self, input_dataset_path_name, input_data_folder_name, input_dataset_folder_name):
        self.dataset_path_name = input_dataset_path_name
        self.raw_data_folder_name = input_data_folder_name
        self.dataset_folder_name = input_dataset_folder_name

        self.input_data_dir = os.path.join(self.dataset_path_name, self.raw_data_foler_name, self.dataset_folder_name)

        self.image_dataset = RawImageDataset(self.input_data_dir)

    def read_data(self):
        # file_name_list = os.listdir(self.input_data_dir)
        file_name_list = sorted(filter(lambda x: os.path.isfile(os.path.join(self.input_data_dir, x)),
                      os.listdir(self.input_data_dir)))

        for file_name in file_name_list:
            cur_path_file_name = os.path.join(self.input_data_dir, file_name)

            # cur_img = read_image(cur_path_file_name)
            # PIL_img = T.ToPILImage()(cur_img)
            # PIL_img.show()

            orig_img = Image.open(cur_path_file_name)
            orig_img.show()

            rotater = T.RandomRotation(degrees=(0, 180))
            rotated_imgs = [rotater(orig_img) for _ in range(4)]
            rotated_imgs[3].show()

            print("break")
