GLOBAL_ATTACK_FOLDER_NAME = r"global"
PATCH_ATTACK_FOLDER_NAME = r"patch"
SEMANTIC_ATTACK_FOLDER_NAME = r"semantic"

## default attack type: 0. 1: global manipulation, 2: patch manipulation, 3: semantic manipulation
GLOBAL_ATTACK = 1
PATCH_ATTACK = 2
SEMANTIC_ATTACK = 3

## Global image manipulation
IMG_ROTATION = 1
IMG_HORIZONTAL_FLIPPING = 2
IMG_AFFINE_TRANSFORMATION = 3
IMG_CROPPING_RESIZE = 4  # RandomResizedCrop
IMG_GAUSSIAN_BLURRING = 5 ## not consider
IMG_COLOR_JITTER = 6 ## not consider
IMG_GRAYSCALE = 7   ## not consider


GLOBAL_MANIPULATION_DICT = {IMG_ROTATION:r"rotation", IMG_HORIZONTAL_FLIPPING:r"flipping",
                            IMG_CROPPING_RESIZE:r"cropping_resize", IMG_AFFINE_TRANSFORMATION:r"affine_trans",
                            IMG_COLOR_JITTER:r"color_jitter", IMG_GRAYSCALE:r"grayscale",
                            IMG_GAUSSIAN_BLURRING: r"gaussian_blur"}