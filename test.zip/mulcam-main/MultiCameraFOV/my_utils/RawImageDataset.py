import os

from torch.utils.data import Dataset
from torchvision.io import read_image
import torchvision.transforms as transforms
from PIL import Image
import torchvision.transforms as T

class RawImageDataset(Dataset):
    def __init__(self, input_data_dir):
        self.__input_data_dir = input_data_dir

        self.__input_data_file_list = sorted(filter(lambda x: os.path.isfile(os.path.join(self.__input_data_dir, x)),
                                                  os.listdir(self.__input_data_dir)))

    def __len__(self):
        return len(self.__input_data_file_list)

    def __getitem__(self, idx):
        ## Tensor[image_channels, image_height, image_width]
        image_name = self.__input_data_file_list[idx]

        image = Image.open(os.path.join(self.__input_data_dir, self.__input_data_file_list[idx]))
        transform = transforms.ToTensor()
        img_tensor = transform(image)
        # T.ToPILImage()(img_tensor.squeeze(0)).show()

        return img_tensor, image_name

        # image = read_image(os.path.join(self.__input_data_dir, self.__input_data_file_list[idx]))
        # return image, image_name

