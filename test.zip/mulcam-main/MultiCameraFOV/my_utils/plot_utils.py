import matplotlib.pyplot as plt
import numpy as np

def plot_sampson_distance(dist_array):
    img_index = np.arange(1, len(dist_array) + 1)
    plt.plot(img_index, dist_array)
    plt.show()

def plot_sampson_distance_hist(dist_array):
    # Calculate the histogram
    hist, bins = np.histogram(dist_array)

    # Convert the frequency to percentage
    percentage = hist / len(dist_array) * 100

    # Plot the percentage distribution
    plt.bar(bins[:-1], percentage, width=np.diff(bins), edgecolor='black')

    # Set labels and title
    plt.xlabel('Value')
    plt.ylabel('Percentage')
    plt.title('Percentage Distribution of Data')

    plt.show()