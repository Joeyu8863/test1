import os

import numpy as np
import yaml

from my_utils.geometricTransformation import findFundamentalMatrix, evaluateRealtimeFundamentalMatrix


class CDefense:
    def __init__(self, raw_img_dir, modified_img_dir, neighbor_camera_config_file_name, input_dataset_name,
                 frame_per_second=24, inital_duration=10):
        self.mRaw_img_dir = raw_img_dir
        self.mModified_img_dir = modified_img_dir
        self.mNeighbor_camera_config_file_name = neighbor_camera_config_file_name

        self.mFrame_per_second = frame_per_second
        self.mInitial_duration = inital_duration

        self.mConfig_data = {}
        self.mNeighbor_list = {}

        self.mDataset_name = input_dataset_name
        self.mAuthentic_fundamental_matrix_file_name = ""

        self.mAuthentic_fundamental_matrix_list = []

        self.mFundamental_matrix_file_dir = os.path.join(os.path.expanduser('~'), r"data/fundamental_matrix",
                                                         self.mDataset_name, r"authentic")
        ## get neighbor camera list
        with open(self.mNeighbor_camera_config_file_name, 'r') as file:
            self.mConfig_data = yaml.safe_load(file)
        ## caluculate authentic fundamental matrix between two neighbor cameras
        self.mNeighbor_list = self.mConfig_data['neighbor']

    def _get_file_list(self, dir_name, start_index=0, end_index=-1):
        cur_camera_img_list = []
        for filename in sorted(os.listdir(dir_name))[start_index: end_index]:
            file_path = os.path.join(os.path.join(dir_name, filename))
            if os.path.isfile(file_path):
                cur_camera_img_list.append(file_path)

        return cur_camera_img_list

    def cal_authentic_fundamental_matrix(self):
        for cur_camera_neighbor_dict in self.mNeighbor_list:
            # get current camera
            cur_camera = list(cur_camera_neighbor_dict.keys())[0]
            # get neighbors of the current camera
            cur_camera_neighbor_list = cur_camera_neighbor_dict[cur_camera].split(r",")

            cur_camera_dir = os.path.join(self.mRaw_img_dir, cur_camera)
            cur_camera_img_list = self._get_file_list(cur_camera_dir, start_index=0,
                                                      end_index=self.mFrame_per_second * self.mInitial_duration)

            for cur_camera_neighbor in cur_camera_neighbor_list:
                cur_camera_neighbor_dir = os.path.join(self.mRaw_img_dir, cur_camera_neighbor)
                cur_camera_neighbor_img_list = self._get_file_list(cur_camera_neighbor_dir, start_index=0,
                                                                   end_index=self.mFrame_per_second *
                                                                             self.mInitial_duration)
                self.mAuthentic_fundamental_matrix_file_name = findFundamentalMatrix(cur_camera_img_list,
                                                                                     cur_camera_neighbor_img_list,
                                                                                     self.mDataset_name,
                                                                                     cur_camera, cur_camera_neighbor)
                pass
            pass
        pass

    def _get_authentic_fundamental_matrix(self, cur_camera, neighbor_camera):
        # if not os.path.isfile(self.mAuthentic_fundamental_matrix_file_name):
        #     self.cal_authentic_fundamental_matrix()
        cur_fundamental_matrix_file_name = os.path.join(self.mFundamental_matrix_file_dir,
                                                        r"fundamental_matrix_list_" + cur_camera + "_" +
                                                        neighbor_camera + ".npy")

        self.mAuthentic_fundamental_matrix_list = np.load(cur_fundamental_matrix_file_name,
                                                          allow_pickle=True)
        return self.mAuthentic_fundamental_matrix_list

    def cal_realtime_fundamental_matrix(self, input_data_dir, attack_type="", is_authentic=1, label_file_name_part=""):
        camera_list = sorted(os.listdir(input_data_dir))
        for cur_camera in camera_list[:1]:
            cur_neighbor_list = []
            for cur_neighbor_dict in self.mNeighbor_list:
                if cur_camera in cur_neighbor_dict:
                    cur_neighbor_list = cur_neighbor_dict[cur_camera].split(",")
                    break
            if len(cur_neighbor_list) < 1:
                print("cannot find neighbor cameras, exit")
                exit(-1)

            if 1 == is_authentic:
                cur_start_index = 0
                cur_count_img = 3000
            else:
                cur_start_index = 3000
                cur_count_img = 1000
            for cur_neighbor in cur_neighbor_list:
                cur_authentic_fundamental_matrix_list = self._get_authentic_fundamental_matrix(cur_camera, cur_neighbor)

                cur_camera_img_list = self._get_file_list(os.path.join(input_data_dir, cur_camera),
                                                          start_index=self.mFrame_per_second * self.mInitial_duration + cur_start_index,
                                                          end_index=self.mFrame_per_second * self.mInitial_duration + cur_start_index + cur_count_img)
                cur_neighbor_img_list = self._get_file_list(os.path.join(input_data_dir, cur_neighbor),
                                                            start_index=self.mFrame_per_second * self.mInitial_duration + cur_start_index,
                                                            end_index=self.mFrame_per_second * self.mInitial_duration + cur_start_index + cur_count_img)
                ## load authentic fundamental matrix

                authentic_f = self._get_authentic_fundamental_matrix(cur_camera, cur_neighbor)
                evaluateRealtimeFundamentalMatrix(np.mean(authentic_f,axis=0), cur_camera_img_list, cur_neighbor_img_list,
                                      self.mDataset_name, cur_camera, cur_neighbor, is_store=1,
                                                  is_authentic_dataset=is_authentic, label_file_name_part=label_file_name_part)
                # findFundamentalMatrix(cur_camera_img_list, cur_neighbor_img_list,
                #                       self.mDataset_name, cur_camera, cur_neighbor,
                #                       is_store=1, attack_type="realtime_" + attack_type)
        pass

    def compare_authentic_realtime_fundamental_matrix(self):

        pass
