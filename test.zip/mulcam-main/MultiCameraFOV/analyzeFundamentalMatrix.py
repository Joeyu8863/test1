import os

import numpy as np


def cosine_similarity(matrix1, matrix2):
    vector1 = matrix1.flatten()
    vector2 = matrix2.flatten()
    dot_product = np.dot(vector1, vector2)
    norm1 = np.linalg.norm(vector1)
    norm2 = np.linalg.norm(vector2)
    cosine_sim = dot_product / (norm1 * norm2)
    return cosine_sim


def euclidean_distance(matrix1, matrix2):
    diff = matrix1 - matrix2
    squared_diff = np.square(diff)
    sum_squared_diff = np.sum(squared_diff)
    euclidean_dist = np.sqrt(sum_squared_diff)
    return euclidean_dist


def mean_squared_error(matrix1, matrix2):
    diff = matrix1 - matrix2
    squared_diff = np.square(diff)
    mse = np.mean(squared_diff)
    return mse


def analyze_fundamental_matrix(folder_name):
    # folder_name = r"/home/angli19/data/fundamental_matrix"
    file_name_list = sorted(os.listdir(folder_name))
    fundamental_matrix_list_list = []
    for cur_file_name in file_name_list:
        cur_folder_file_name = os.path.join(folder_name, cur_file_name)
        fundamental_matrix_list = np.load(cur_folder_file_name, allow_pickle=True)
        fundamental_matrix_list_list.append(fundamental_matrix_list)
        # distance_matrix = np.zeros((len(fundamental_matrix_list),len(fundamental_matrix_list)))
        # for i in range(0, len(fundamental_matrix_list)):
        #     for j in range(i+1, len(fundamental_matrix_list)):
        #         # distance_matrix[i,j] = cosine_similarity(fundamental_matrix_list[i], fundamental_matrix_list[j])
        #         # distance_matrix[i,j] = mean_squared_error(fundamental_matrix_list[i], fundamental_matrix_list[j])
        #         distance_matrix[i,j] = euclidean_distance(fundamental_matrix_list[i], fundamental_matrix_list[j])

    distance_two_pair_matrix = np.zeros((len(fundamental_matrix_list_list), len(fundamental_matrix_list_list)))
    selected_matrix = 0
    for i in range(0, len(fundamental_matrix_list_list)):
        for j in range(i + 1, len(fundamental_matrix_list_list)):
            # distance_two_pair_matrix[i,j] = euclidean_distance(fundamental_matrix_list_list[i][selected_matrix],
            #                                                    fundamental_matrix_list_list[j][selected_matrix])
            # distance_two_pair_matrix[i,j] = mean_squared_error(fundamental_matrix_list_list[i][8], fundamental_matrix_list_list[j][8])
            distance_two_pair_matrix[i, j] = cosine_similarity(fundamental_matrix_list_list[i][8],
                                                               fundamental_matrix_list_list[j][8])


def compare_fundamental_matrix(authentic_fundamental_matrix_file_name, realtime_fundamental_matrix_file_name):
    authentic_fundamental_matrix_list = np.load(authentic_fundamental_matrix_file_name, allow_pickle=True)
    realtime_fundamental_matrix_file_name = np.load(realtime_fundamental_matrix_file_name, allow_pickle=True)
    distance_two_pair_matrix = np.zeros(
        (len(authentic_fundamental_matrix_list), len(realtime_fundamental_matrix_file_name)))
    selected_matrix = 0
    for i in range(0, len(authentic_fundamental_matrix_list)):
        print(i)
        for j in range(0, len(realtime_fundamental_matrix_file_name)):
            distance_two_pair_matrix[i, j] = euclidean_distance(authentic_fundamental_matrix_list[i],
                                                                realtime_fundamental_matrix_file_name[j])
            # distance_two_pair_matrix[i,j] = mean_squared_error(authentic_fundamental_matrix_list[i],
            #                                                    realtime_fundamental_matrix_file_name[j])
            # distance_two_pair_matrix[i, j] = cosine_similarity(authentic_fundamental_matrix_list[i],
            #                                                    realtime_fundamental_matrix_file_name[j])
            pass

    pass
