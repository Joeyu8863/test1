# from attack.CAttack import CAttack
from my_utils import Constants
import CAttack
'''
Semantic image manipulation
'''


class CSemanticAttack(CAttack):
    def __init__(self, raw_img_dir, out_img_dir):
        super(CSemanticAttack, self).__init__(raw_img_dir, out_img_dir)
        self.mAttack_type = Constants.SEMANTIC_ATTACK

    # def attack_pipeline(self, compromised_cam_num=1, compromised_cam_list=[], is_overlapping=0):
    #     super(CSemanticAttack, self)._attack_pipeline(compromised_cam_num, compromised_cam_list, is_overlapping)

    def _find_overlapping_area(self):
        pass

    def _manipulate_data(self):
        pass