import abc
import os
from random import random


class CAttack:
    """
    Construct a new 'CAttack' object
    :param raw_img_dir: the directory path to raw images
    :param out_img_dir: the directory path to the modified images
    """
    def __init__(self, raw_img_dir, out_img_dir="", attack_type=1):
        if raw_img_dir == r"":
            print(r"Error in CAttack->__init__: The input image path should not be none")
            exit(-1)

        self.mRaw_img_dir = raw_img_dir
        if out_img_dir != "":
            self.mOut_img_dir = out_img_dir
        else:
            '''
            if output image directory is null, store modified images to default
            director: the directory of project
            '''
            self.mOut_img_dir = os.path.dirname(os.path.realpath(__file__))
        ## default attack type: 0. 1: global manipulation, 2: patch manipulation, 3: semantic manipulation
        self.mAttack_type = 0

    """
     Start a attack pipeline
    :param compromised_cam_num: number of compromised cameras (>=1)
    :param compromised_cam_list: list of compromised camera #
    :param is_overlapping: manipulate overlapping area(=1) or non-overlapping area (=0)
    """
    def attack_pipeline(self, compromised_cam_num=1, compromised_cam_list=[], is_overlapping=1):
        if compromised_cam_num < 1:
            print(r"Error in CAttack->attack_pipeline: The number of compromised cameras < 1")
            exit(-1)
        if compromised_cam_num != len(compromised_cam_list):
            print(r"Error in CAttack->attack_pipeline: Compromised_cam_num == len(compromised_cam_list)")
            exit(-1)

        ## set up if attackers manipulate overlapping area
        self.mIs_overlapping = is_overlapping
        ## Step 1. select compromised camera
        print("==== Start select compromised cameras ====")
        self._select_compromised_camera(compromised_cam_num, compromised_cam_list)
        print("==== End select compromised cameras ====")
        if 1 != self.mAttack_type:
            ## Step 2 (If needed). find overlapping area if it is patch manipulation or semantic manipulation
            ## global manipulation must change the overlapping area, so no need to find overlapping area
            print("==== Start find overlapping and non-overlapping areas ====")
            self._find_overlapping_area()
            print("==== End find overlapping and non-overlapping areas ====")
        ## Step 2 or 3. Data manipulation
        print("==== Start manipulate data ====")
        self._manipulate_data()
        print("==== End manipulate data ====")

    def _select_compromised_camera(self, compromised_cam_num=1, compromised_cam_list=[]):
        self.mCompromised_cam_num = compromised_cam_num

        if len(compromised_cam_list) < 1:
            self.mCompromised_cam_list = random.choices(os.listdir(self.mRaw_img_dir),
                                                        k=compromised_cam_num)
        else:
            self.mCompromised_cam_list = compromised_cam_list

    def _find_overlapping_area(self):
        pass

    def _manipulate_data(self):
        pass

