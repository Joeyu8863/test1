import os.path
import shutil


from attack.CAttack import CAttack
from my_utils import Constants
from my_utils.Data_Mani_pipeline import Manipulate_img_pipeline

'''
Global image manipulation
'''


class CGlobalAttack(CAttack):
    def __init__(self, raw_img_dir, out_img_dir="", manipulate_tech_list=[], rotation_angle=0):
        out_img_dir = os.path.join(out_img_dir, Constants.GLOBAL_ATTACK_FOLDER_NAME)
        super(CGlobalAttack, self).__init__(raw_img_dir, out_img_dir)

        ## assign attack type
        self.mAttack_type = Constants.GLOBAL_ATTACK
        ## Data manipulation techniques
        if 0 == len(manipulate_tech_list):
            self.mManipulate_tech_list = [Constants.IMG_ROTATION, Constants.IMG_HORIZONTAL_FLIPPING,
                                          Constants.IMG_AFFINE_TRANSFORMATION, Constants.IMG_CROPPING_RESIZE,
                                          Constants.IMG_GAUSSIAN_BLURRING, Constants.IMG_COLOR_JITTER,
                                          Constants.IMG_GRAYSCALE]
        else:
            self.mManipulate_tech_list = manipulate_tech_list

        ## attack parameter
        self.rotation_angle = rotation_angle

    def _manipulate_data(self):
        ## modify images under each compromised cameras
        camera_fold_list = sorted(os.listdir(self.mRaw_img_dir))
        ## for each compromised camera, we perform all manipulation
        for cur_mani_type in self.mManipulate_tech_list:
            for cur_camera_fold in camera_fold_list:
                if Constants.IMG_ROTATION == cur_mani_type:
                    cur_output_folder = os.path.join(self.mOut_img_dir,
                                                     Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type],
                                                     str(self.rotation_angle),
                                                     cur_camera_fold)
                elif Constants.IMG_HORIZONTAL_FLIPPING == cur_mani_type:
                    cur_output_folder = os.path.join(self.mOut_img_dir,
                                                     Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type],
                                                     cur_camera_fold)
                elif Constants.IMG_AFFINE_TRANSFORMATION == cur_mani_type:
                    cur_output_folder = os.path.join(self.mOut_img_dir,
                                                     Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type],
                                                     cur_camera_fold)
                elif Constants.IMG_CROPPING_RESIZE == cur_mani_type:
                    cur_output_folder = os.path.join(self.mOut_img_dir,
                                                     Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type],
                                                     cur_camera_fold)
                elif Constants.IMG_GAUSSIAN_BLURRING == cur_mani_type:
                    cur_output_folder = os.path.join(self.mOut_img_dir,
                                                     Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type],
                                                     cur_camera_fold)
                elif Constants.IMG_COLOR_JITTER == cur_mani_type:
                    cur_output_folder = os.path.join(self.mOut_img_dir,
                                                     Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type],
                                                     cur_camera_fold)
                elif Constants.IMG_GRAYSCALE == cur_mani_type:
                    cur_output_folder = os.path.join(self.mOut_img_dir,
                                                     Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type],
                                                     cur_camera_fold)

                if cur_camera_fold in self.mCompromised_cam_list:
                    ## if the camera is compromised, manipulation all image data and store them into
                    ## the modified_images directory
                    print("Manipulation Type: " + Constants.GLOBAL_MANIPULATION_DICT[cur_mani_type] +
                          ", Compromised camera: #" + cur_camera_fold)

                    Manipulate_img_pipeline(os.path.join(self.mRaw_img_dir, cur_camera_fold), cur_mani_type,
                                            cur_output_folder,
                                            rotation_angle=self.rotation_angle)
                else:
                    ## if the camera is not compromised, directory store the raw images into the modified_images folder
                    print("For " + cur_camera_fold + ", copy the raw images")

                    if os.path.exists(cur_output_folder):
                        shutil.rmtree(cur_output_folder)
                    shutil.copytree(os.path.join(self.mRaw_img_dir, cur_camera_fold),
                                    cur_output_folder)
        pass
