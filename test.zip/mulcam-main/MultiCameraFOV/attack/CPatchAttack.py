import os
import glob
from attack.CAttack import CAttack
# import CAttack
from my_utils import Constants
from my_utils.utils import find_overlapping_area, find_overlapping_area_1

'''
Patch-based image manipulation
'''


class CPatchAttack(CAttack):
    def __init__(self, raw_img_dir, out_img_dir):
        out_img_dir = os.path.join(out_img_dir, Constants.PATCH_ATTACK_FOLDER_NAME)
        super(CPatchAttack, self).__init__(raw_img_dir, out_img_dir)
        self.mAttack_type = Constants.PATCH_ATTACK

    # def attack_pipeline(self, compromised_cam_num=1, compromised_cam_list=[], is_overlapping=0):
    #     super(CPatchAttack, self)._attack_pipeline(compromised_cam_num, compromised_cam_list, is_overlapping)
    def _find_overlapping_area(self):
        ## for images uploaded by compromised cameras
        raw_img_folder_list = sorted(os.listdir(self.mRaw_img_dir))
        for cur_compromised_camera_fold in self.mCompromised_cam_list:
            ## get all image files under compromised camera
            cur_compromised_img_list = []
            for filename in sorted(os.listdir(os.path.join(self.mRaw_img_dir, cur_compromised_camera_fold))):
                file_path = os.path.join(os.path.join(self.mRaw_img_dir, cur_compromised_camera_fold), filename)
                if os.path.isfile(file_path):
                    cur_compromised_img_list.append(file_path)
            for cur_raw_img_fold in raw_img_folder_list:
                if cur_raw_img_fold != cur_compromised_camera_fold: #r'C6' == cur_raw_img_fold:
                    target_img_list = []
                    for filename in sorted(os.listdir(os.path.join(self.mRaw_img_dir, cur_raw_img_fold))):
                        file_path = os.path.join(os.path.join(self.mRaw_img_dir, cur_raw_img_fold), filename)
                        if os.path.isfile(file_path):
                            target_img_list.append(file_path)

                    for cur_compromised_img, cur_target_img in zip(cur_compromised_img_list, target_img_list):
                        if cur_compromised_img[cur_compromised_img.rfind(r"/")+1:cur_compromised_img.rfind(r".")] \
                                == cur_target_img[cur_target_img.rfind(r"/")+1:cur_target_img.rfind(r".")]:
                            # find_overlapping_area(cur_compromised_img, cur_target_img)
                            find_overlapping_area_1(cur_compromised_img, cur_target_img)
                        else:
                            pass

                else:
                    pass


    def _manipulate_data(self):
        pass
